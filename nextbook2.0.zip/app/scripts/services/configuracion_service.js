'use strict';

/**
 * @ngdoc service
 * @name nextbook20App.configuracionService
 * @description
 * # configuracionService
 * Service in the nextbook20App.
 */
angular.module('nextbook20App')
  .service('configuracionService', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
