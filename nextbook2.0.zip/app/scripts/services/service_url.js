'use strict';

/**
 * @ngdoc service
 * @name nextbook20App.serviceUrl
 * @description
 * # serviceUrl
 * Service in the nextbook20App.
 */
angular.module('nextbook20App')
  .service('serviceUrl', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
