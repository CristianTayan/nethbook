'use strict';

/**
 * @ngdoc function
 * @name nextbook20App.controller:AppCtrl
 * @description
 * # AppCtrl
 * Controller of the nextbook20App
 */
angular.module('nextbook20App')
  	.controller('app_Ctrl', function () {
    	// $scope.apps = {}
  	});
