'use strict';

/**
 * @ngdoc function
 * @name nextbook20App.controller:InicioCtrl
 * @description
 * # InicioCtrl
 * Controller of the nextbook20App
 */
angular.module('nextbook20App')
  .controller('inicio_Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
